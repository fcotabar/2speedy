# 2Speedy Sports - Tienda virtual
Proyecto de una tienda virtual deportiba para el módulo de TSP del Politécnico Grancolombiano.
Se desarrolló con PHP, Bootstrap y MySQL.
